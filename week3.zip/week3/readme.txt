Wesley Rorije, Adrian Wilhelm
04-12-2020
2.0


Name
Pypovray simulation


Description
this project contains 2 python scripts that makes an multiple Scenes into a simulation using ray tracing. 
Assignment 3 creates a simulation of a box moving in a triangle wave form. 
Assignment 4 creates a simulation with a moving camera object.
In this simulation you will see the Objects: Cylinder, Sphere and a self made Legend that gets imported into the assignment4.py file

Installation
Install the vapory library
Install the pypovray library
Run the assignment3.py file
Run the assignment4.py file


Usage
Open the created .mp4 file to see the created simulation


Support
You can find tutorials and information at the github or bitbucket repository from the bioinformatics course.


Authors and acknowledgment
credits Wesley Rorije & Adrian Wilhelm
